/**
 * BodyMind OS — License Gate
 * Client-side license validation for freemium model
 */
(function() {
  'use strict';

  function initSplash() {
    const state = window.BM.state.loadState();

    // Already has a valid license — skip splash
    if (state.initialized && (state.licenseTier === 'pro' || state.licenseTier === 'studio')) {
      showApp();
      return;
    }

    // Show splash for license entry or free continuation
    const splash = document.getElementById('splash');
    const activateBtn = document.getElementById('btn-activate');
    const freeBtn = document.getElementById('btn-free-tier');
    const errorMsg = document.getElementById('splash-error');
    const upgradeInfo = document.getElementById('splash-upgrade-info');

    upgradeInfo.classList.remove('hidden');

    activateBtn.addEventListener('click', () => {
      const key = document.getElementById('license-key').value.trim();

      if (!key) {
        showError('Please enter your license key.');
        return;
      }

      const result = window.BM.state.validateLicenseKey(key);
      if (!result) {
        showError('Invalid key format. Expected: BOMD-XXXX-XXXX-XXXX');
        return;
      }

      // Activate
      window.BM.state.setLicense(result.tier);
      showApp();
    });

    freeBtn.addEventListener('click', () => {
      const state = window.BM.state.loadState();
      state.licenseTier = 'free';
      state.initialized = true;
      window.BM.state.saveState(state);
      showApp();
    });

    function showError(msg) {
      errorMsg.textContent = msg;
      errorMsg.classList.remove('hidden');
    }
  }

  function showApp() {
    const splash = document.getElementById('splash');
    const app = document.getElementById('app');
    splash.style.display = 'none';
    app.classList.add('visible');
    updateTierBadge();
  }

  function updateTierBadge() {
    const state = window.BM.state.loadState();
    const badge = document.getElementById('tier-badge');

    if (state.licenseTier === 'pro') {
      badge.textContent = 'Pro';
      badge.className = 'tier-badge tier-pro';
    } else if (state.licenseTier === 'studio') {
      badge.textContent = 'Studio';
      badge.className = 'tier-badge tier-pro';
    } else {
      badge.textContent = 'Starter';
      badge.className = 'tier-badge tier-free';
    }
  }

  // Expose
  window.BM = window.BM || {};
  window.BM.license = {
    initSplash,
    showApp,
    updateTierBadge
  };
})();
