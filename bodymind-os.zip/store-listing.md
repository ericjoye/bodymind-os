# Bodymind Os — Store Listing

## Name
Bodymind Os

## Short description (≤132 chars)
This is the business operating system for independent massage therapists that handles scheduling, client intake, session notes, cont

## Detailed description
This is the business operating system for independent massage therapists that handles scheduling, client intake, session notes, contraindication tracking, and CE compliance — built specifically for solo practitioners who serve clients but aren't managing a clinic.

Solo massage therapists have a unique workflow that generic booking tools don't address:
1. **Health intake + contraindications**: Every new client must fill out a health history form. Certain conditions (DVT, osteoporosis, pregnancy, cancer treatment) require technique modification or refusal. Paper forms get lost; generic tools don't flag contraindications.
2. **Session notes**: Therapists need to record what they did, what worked, client pressure preferences, areas of tension. This is both clinical documentation and liability protection.
3. **CE compliance tracking**: 49 states require continuing education for license renewal. Missing CE deadlines = license suspension = cannot work. Currently tracked manually.
4. **Supply tracking**: Oils, lotions, linens, laundry — small costs that add up. No tool tracks this for solo therapists.
5. **No-show reduction**: Massage sessions are 60-90 min blocks. One no-show = $80-150 lost. Generic booking tools don't send the right reminders for bodywork appointments.

Existing tools fail:
- **Mindbody**: $120-250/mo — built for multi-staff spas, overkill for solo
- **Vagaro**: $25-89/mo — marketplace pushes their booking.com alternative, complex UI
- **Booksy**: Commission on bookings — therapists hate losing 2-5% per session
- **Fresha**: Free but monetizes payment processing; no massage-specific features
- **Calendly/Acuity**: Generic — no intake forms, no contraindication flags, no session notes
- **GlossGenius**: $24/mo — beauty/nails focus, no massage-specific workflow

## Key features
**Phase 1 — Core (build first)**:
1. Booking page (customizable, embeddable, mobile-first)
2. Calendar management (availability, recurring blocks, buffer time between sessions)
3. Client CRM (contact info, visit history, tags)
4. Digital intake forms (health history, consent, COVID screening) — with contraindication flagging
5. Session notes (SOAP format: Subjective, Objective, Assessment, Plan)
6. Automated reminders (email/SMS 24h + 2h before appointment)
7. Payment integration (Stripe — accept deposits, full payments, tips)
8. Basic reporting (revenue, client retention, no-show rate)

**Phase 2 — Differentiators (post-launch)**:
9. CE tracker (log hours, track by state requirement, renewal deadline alerts)
10. Supply inventory tracker
11. Mobile app (therapists often take notes on their phone between sessions)
12. Insurance receipt generation (for HSA/FSA reimbursement)

## Category
Productivity / Developer Tools

## Keywords
bodymind, os, bodymind os
